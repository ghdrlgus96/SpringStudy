package org.zerock.mapper;

import org.zerock.domain.ReplyVO;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.zerock.domain.Criteria;

public interface ReplyMapper {
	public int insert(ReplyVO vo);
	public ReplyVO read(Long bno);
	public int delete(long rno);
	public int update(ReplyVO reply);
	public List<ReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("bno") Long bno);
	//public int getCountByBno(Long bno);
}
